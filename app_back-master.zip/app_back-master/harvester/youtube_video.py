import argparse

from sys import stdout
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

import uuid
import json
from random import randint, choice
import requests


youtube = None

def get_videos(options, videoIds):
    global youtube

    videos = youtube.videos()
    request = videos.list(id=videoIds, part='snippet,statistics,contentDetails')
    response = request.execute()

    return response['items']


def youtube_search(options):
    global youtube
    
    nextPageToken = None
    count = 0
    total = list()

    try:
        while True:        
            if count >= options.count:
                raise Exception("Limit is reached")

            search = youtube.search()
            request = search.list(q=options.q, part='id', type='video', pageToken=nextPageToken, maxResults=50)
            response = request.execute()

            videos = response['items']
            total += get_videos(options, ','.join(list(map(lambda x: x['id']['videoId'], videos))))

            count += len(videos)
            nextPageToken = response.get('nextPageToken')

            print(f'{count}/{options.count}')

            if nextPageToken == None:
                raise Exception("It was last page")

    except Exception as e:
        print(e)
            
    return total

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('--key',
                        type=str,
                        required=True,
                        help='Youtube API developer key')

    parser.add_argument('--q',
                        help='Search term',
                        type=str,
                        default='Google')

    parser.add_argument('--count',
                        type=int,
                        help='Results count (min: 50)',
                        default=50)

    parser.add_argument('-o', '--output',
                        type=str,
                        help='Output file (default stdout)')

    args = parser.parse_args()
    youtube = build('youtube', 'v3', developerKey=args.key)

    fp = stdout if args.output == None else open(args.output, 'a')

    print(json.dump(youtube_search(args), fp, indent=4))
