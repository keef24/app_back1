import argparse
from random import choice, randint
import youtube_video
from googleapiclient.discovery import build
from argparse import Namespace
import json
import requests
import aniso8601.duration
import os
import datetime


UPLOAD_URL = 'https://backendtr.herokuapp.com/'


def process_duration(dstr):
    duration_str = str(aniso8601.duration.parse_duration(dstr))
    hours, mins, secs = duration_str.split(':')

    mins = mins.lstrip('0')
    hours = hours.lstrip('0')
    secs = secs.lstrip('0')

    if not hours:
        if not mins:
            return f'{secs}s'
        return f'{mins}m'
    return f'{hours}h{mins}m'


categories_collection = [
    {
        'id': 2779,
        'title': 'Session format',
        'items': [
            {
                'id': 13199,
                'name': '30minutes',
                'sort': 1,
                'translatedName': {
                        'ja': '30分',
                        'en': '30minutes'
                }
            },
            {
                'id': 13200,
                'name': '50minutes',
                'sort': 2,
                'translatedName': {
                        'ja': '50分',
                        'en': '50minutes'
                }
            }
        ],
        'sort': 1,
        'translatedTitle': {
            'ja': '発表時間',
            'en': 'Session format'
        }
    },
    {
        'id': 2780,
        'title': 'Language',
        'items': [
            {
                'id': 13202,
                'name': 'Russian',
                'sort': 1,
                'translatedName': {
                        'ja': 'Русский',
                        'en': 'Russian'
                }
            },
            {
                'id': 13201,
                'name': 'English',
                'sort': 2,
                'translatedName': {
                        'ja': 'Английский',
                        'en': 'English'
                }
            },
            {
                'id': 13203,
                'name': 'Mixed',
                'sort': 3,
                'translatedName': {
                        'ja': '日英混合',
                        'en': 'Mixed'
                }
            }
        ],
        'sort': 2,
        'translatedTitle': {
            'ja': '発表言語',
            'en': 'Language'
        }
    },
    {
        'id': 2863,
        'title': 'カテゴリ / Category',
        'items': list(),
        'sort': 3,
        'translatedTitle': {
            'ja': 'カテゴリ',
            'en': 'Category'
        }
    }
]

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('--key',
                        type=str,
                        default='AIzaSyA3rNcxIBNWFdhhdCfvNkOs-kQSNyPB8Mg',
                        help='Youtube API developer key')

    parser.add_argument('--q',
                        help='Video search terms',
                        type=str,
                        default=['Data Science'],
                        nargs='+')

    parser.add_argument('--s',
                        help='Session search terms',
                        type=str,
                        default=['Python'],
                        nargs='+')

    parser.add_argument('--upload',
                        action='store_true')

    parser.add_argument('--count',
                        type=int,
                        help='Count results by term (min, default: 50)',
                        default=50)

    args = parser.parse_args()
    youtube_video.youtube = build('youtube', 'v3', developerKey=args.key)

    total_video = []
    for term in args.q:
        print(f"Search for {term}")
        search_args = Namespace(key=args.key, q=term, count=args.count // len(args.q))
        total_video += youtube_video.youtube_search(search_args)

    total_sessions = []
    for term in args.s:
        print(f"Search for {term}")
        search_args = Namespace(key=args.key, q=term, count=50)
        total_sessions += youtube_video.youtube_search(search_args)

    # get unique videos
    videos = list({item['id']: item for item in total_video}.values())

    # get unique sessions
    sessions = list({item['id']: item for item in total_sessions}.values())

    channels = list(map(lambda x: {
        'id': x['snippet']['channelId'],
        'title': x['snippet']['channelTitle'],
        'avatar': x['snippet']['thumbnails']['default']['url']
    }, videos))

    speakers = list(map(lambda x: {
        'id': x['snippet']['channelId'],
        'title': x['snippet']['channelTitle'],
        'avatar': x['snippet']['thumbnails']['default']['url']
    }, sessions))

    # get unique channels
    channels = list({item['id']: item for item in channels}.values())

    # get unique speakers
    speakers = list({item['id']: item for item in speakers}.values())

    channels_collection = [
        {
            'id': channel['id'],
            'firstName': channel['title'],
            'lastName': '',
            'fullName': channel['title'],
            'bio': '',
            'tagLine': '',
            'profilePicture': channel['avatar'],
            'isTopSpeaker': choice([True, False]),
            'links': ['https://www.youtube.com/channel/{}/'.format(channel['id'])],
            'sessions': []
        } for channel in channels]

    speakers_collection = [
        {
            'id': speaker['id'],
            'firstName': speaker['title'],
            'lastName': '',
            'fullName': speaker['title'],
            'bio': '',
            'tagLine': '',
            'profilePicture': speaker['avatar'],
            'isTopSpeaker': choice([True, False]),
            'links': ['https://www.youtube.com/channel/{}/'.format(speaker['id'])],
            'sessions': []
        } for speaker in speakers]

    video_categories = [
        {
            'id': randint(10000, 100000),
            'name': ','.join(item['snippet'].get('tags') or list()) ,
            'sort': randint(10000, 100000),
            'translatedName': {
                'ja': '',
                'en': ''
            }
        } for item in videos]

    categories_collection[2]['items'] += video_categories

    sessions_categories = [
        {
            'id': randint(10000, 100000),
            'name': ','.join(item['snippet'].get('tags') or list()) ,
            'sort': randint(10000, 100000),
            'translatedName': {
                'ja': '',
                'en': ''
            }
        } for item in sessions]
    
    categories_collection[2]['items'] += sessions_categories

    video_collection = [
        {
            'id': item['id'],
            'title': item['snippet']['title'],
            'videoUrl': 'https://www.youtube.com/watch?v={}'.format(item['id']),
            'description': item['snippet']['description'],
            'startsAt': choice(['2018-02-07T10:00:00+09:00', '2019-02-08T10:00:00+09:00']),
            'endsAt': choice(['2018-02-07T10:00:00+09:00', '2019-02-08T10:00:00+09:00']),
            'categoryItems': [13199, 13201 if (item['snippet'].get('defaultAudioLanguage') == 'en') else 13202, video_categories[i]['id']], # TODO
            'speakers': [item['snippet']['channelId']],
            'isServiceSession': False,
            'roomId': 3869,
            'isPlenumSession': False,
            'questionAnswers': [],
            'slideUrl': None,
            'interpretationTarget': choice([True, False]),
            'message': None,
            'englishTitle': item['snippet']['title'],
            'sessionType': 'normal',
            'forBeginners': choice([True, False]),
            'startsAtWithTZ': choice(['2018-02-07T10:00:00+09:00', '2019-02-08T10:00:00+09:00']),
            'endsAtWithTZ': choice(['2019-02-07T10:20:00+09:00', '2019-02-08T10:20:00+09:00']),
            'duration': process_duration(item['contentDetails']['duration']),
            'viewCount': item['statistics'].get('viewCount') or 0,
            'likeCount': item['statistics'].get('likeCount') or 0

        } for i, item in enumerate(videos)]

    sessions_collection = [
        {
            'id': item['id'],
            'title': item['snippet']['title'],
            'videoUrl': 'https://www.youtube.com/watch?v={}'.format(item['id']),
            'description': item['snippet']['description'],
            'startsAt': choice(['2018-02-07T10:00:00+09:00', '2019-02-08T10:00:00+09:00']),
            'endsAt': choice(['2018-02-07T10:00:00+09:00', '2019-02-08T10:00:00+09:00']),
            'categoryItems': [13199, 13201 if (item['snippet'].get('defaultAudioLanguage') == 'en') else 13202, sessions_categories[i]['id']], # TODO
            'speakers': [item['snippet']['channelId']],
            'isServiceSession': False,
            'roomId': 3869,
            'isPlenumSession': False,
            'questionAnswers': [],
            'slideUrl': None,
            'interpretationTarget': choice([True, False]),
            'message': None,
            'englishTitle': item['snippet']['title'],
            'sessionType': 'normal',
            'forBeginners': choice([True, False]),
            'startsAtWithTZ': choice(['2018-02-07T10:00:00+09:00', '2019-02-08T10:00:00+09:00']),
            'endsAtWithTZ': choice(['2019-02-07T10:20:00+09:00', '2019-02-08T10:20:00+09:00'])
        } for i, item in enumerate(sessions)]

    collections_path = './collections'

    if not os.path.exists(collections_path):
        os.makedirs(collections_path)

    json.dump(sessions_collection, open(os.path.join(collections_path, "sessions_collection.json"), "w"), indent=4)
    json.dump(categories_collection, open(os.path.join(collections_path, "categories_collection.json"), "w"), indent=4)
    json.dump(channels_collection, open(os.path.join(collections_path, "channels_collection.json"), "w"), indent=4)
    json.dump(video_collection, open(os.path.join(collections_path, "videos_collection.json"), "w"), indent=4)
    json.dump(speakers_collection, open(os.path.join(collections_path, "speakers_collection.json"), "w"), indent=4)
    
    print('Collections saved')

    try:
        if args.upload:
            requests.get(f'{UPLOAD_URL}/delete_videos')
            print('Videos deleted')
            requests.get(f'{UPLOAD_URL}/delete_channels')
            print('Channels deleted')
            requests.get(f'{UPLOAD_URL}/delete_categories')
            print('Categories deleted')
            requests.get(f'{UPLOAD_URL}/delete_sessions')
            print('Sessions deleted')
            requests.get(f'{UPLOAD_URL}/delete_speakers')
            print('Speakers deleted')

            requests.post(f'{UPLOAD_URL}/videos', json=video_collection)
            print(f'{len(video_collection)} videos uploaded')

            requests.post(f'{UPLOAD_URL}/channels', json=channels_collection)
            print(f'{len(channels_collection)} channels uploaded')
            
            requests.post(f'{UPLOAD_URL}/categories', json=categories_collection)
            print(f'{len(categories_collection)} categories uploaded')
            
            requests.post(f'{UPLOAD_URL}/sessions', json=sessions_collection)
            print(f'{len(sessions_collection)} sessions uploaded')
            
            requests.post(f'{UPLOAD_URL}/speakers', json=speakers_collection)
            print(f'{len(speakers_collection)} speakers uploaded')

    except Exception as e:
        print(e)