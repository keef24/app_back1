package com.conference.api.repository;

import com.conference.api.documents.Channel;
import com.conference.api.documents.Session;
import com.conference.api.documents.Video;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * SessionRepo
 */

public interface VideoRepo extends MongoRepository<Video, String>{

    
}

