package com.conference.api.repository;

import com.conference.api.documents.Channel;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ChannelRepo extends MongoRepository<Channel, String> {

}
