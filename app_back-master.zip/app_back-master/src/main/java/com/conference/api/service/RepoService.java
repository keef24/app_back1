package com.conference.api.service;

import com.conference.api.documents.Sponsers;
import com.conference.api.documents.Timetable;
import com.conference.api.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * TimeTableService
 */
@Service
public class RepoService {

    @Autowired
    private SessionRepo session;
    @Autowired
    private CategoryRepo category;
    @Autowired
    private QuestionsRepo question;
    @Autowired
    private SpeakerRepo speaker;
    @Autowired
    private RoomRepo room;
    @Autowired
    private SponserRepo sponser;
    @Autowired
    private VideoRepo video;
    @Autowired
    private ChannelRepo channel;


    public Timetable getTimeTable(){

        return new Timetable(session.findAll(),
                speaker.findAll(),
                question.findAll(),
                category.findAll(),
                room.findAll(),
                video.findAll(),
                channel.findAll());

    }

    public Sponsers getSponsers(){
        return new Sponsers(sponser.findByKind("platinum"),
                            sponser.findByKind("gold"),
                            sponser.findByKind("supporter"),
                            sponser.findByKind("tech"));
    }

}